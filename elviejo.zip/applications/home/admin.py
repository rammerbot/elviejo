from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(Home)
admin.site.register(Suscribers)
admin.site.register(Contact)