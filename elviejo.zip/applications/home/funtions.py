def comprobar_nombres(dato):
    if len(dato) < 3:
        return False
    else:
        True
        