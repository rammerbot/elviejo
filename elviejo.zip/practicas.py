import random
import string


"""def regresion(n):
    print(n)
    if n>0:
        regresion(n-1)


regresion(10)  """

"""def factorial(n):

    if n == 1:
        return 1
    return n * factorial(n-1)

print(factorial(3))"""

b = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,]
i = [16,17,18,19,20,21,22,23,24,25,26,27,28,29,30]
n = [31,32,33,34,35,36,37,38,39,40,41,42,43,44,45]
g = [46,47,48,49,50,51,52,53,54,55,56,57,58,59,60]
o = [61,62,63,64,65,66,67,68,69,70,71,72,73,74,75]

numero1 = random.sample(b,5)
numero2 = random.sample(i,5)
numero3 = random.sample(n,5)
numero4 = random.sample(g,5)
numero5 = random.sample(o,5)
print(numero1)
print(numero2)
print(numero3)
print(numero4)
print(numero5)

